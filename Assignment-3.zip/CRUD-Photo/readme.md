npm init -y
npm install express
npm install sequelize
npm install --save-dev sequelize-cli
npm install pg
npx sequelize init << untuk membuat config model seeder

node app.js << run program

npx jest --runInBand --detectOpenHandles --forceExit << run test